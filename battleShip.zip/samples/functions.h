//
// Created by carson on 8/28/20.
//

#ifndef INC_366_DEMOS_FUNCTIONS_H
#define INC_366_DEMOS_FUNCTIONS_H

#define MAX_VAL 100
enum sampleEnum {A, B, C};

void func_2();

#endif //INC_366_DEMOS_FUNCTIONS_H
