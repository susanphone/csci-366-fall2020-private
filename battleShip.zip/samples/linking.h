#ifndef INC_366_DEMOS_LINKING_H
#define INC_366_DEMOS_LINKING_H

extern int global_int;

void print_linking2_data();

#endif