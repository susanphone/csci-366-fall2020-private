#include "gtest/gtest.h"

char * print_binary_representation(unsigned int i, char *buffer){
    //    add buffer 0b to the front
    buffer[0] = '0';
    buffer[1] = 'b';
    // fill out remaining 32 bits, 1 or 0 depending on the value in the number i
    unsigned int total = i;
    int index = 33;
    /** HIS SOLUTION
char * print_binary_representation(unsigned int i, char *buffer){
buffer[0] = '0';
buffer[1] = 'b';
for (int i = 0; i < 32; i++) {
     unsigned int mask = 1u << (31u - i);
     if (value & mask) {
        buffer[i + 2] = '1';  // 0 is false and non-zero is true
     } else {
        buffer[i + 2] = '0';
        }
     }
return buffer;
}
*/

    while (index > 1) {
        int r = total % 2;
        int d = total / 2;

        buffer[index] = r + '0';
        index--;
        total = d;
    }

    return buffer;
}

/* PROBLEM 1: Implement a print_binary_representation function that takes an
 * unsigned integer and created as string representation of the binary values
 * of that number.
 *0b00000000000000000000000000000000
 * The test below show what the expected values are for given inputs
 */
TEST(print_binary_representation, works) {
    // row 1
    char buffer[50] = {0}; // init to 0
    EXPECT_STREQ("0b00000000000000000000000000000000", print_binary_representation(0, buffer));
    EXPECT_STREQ("0b00000000000000000000000000000001", print_binary_representation(1, buffer));
    EXPECT_STREQ("0b00000000000000000000000000000010", print_binary_representation(2, buffer));
    EXPECT_STREQ("0b00000000000000000000000000000011", print_binary_representation(3, buffer));
    EXPECT_STREQ("0b00000000000000000000000000000100", print_binary_representation(4, buffer));
    EXPECT_STREQ("0b00000001110111111001101001000010", print_binary_representation(31431234, buffer));
    EXPECT_STREQ("0b00011011111000100100001101011101", print_binary_representation(467813213, buffer));
    EXPECT_STREQ("0b11111111111111111111111111111111", print_binary_representation(UINT32_MAX, buffer));
}

/* PROBLEM 2: The test below fails.  Change the signature of set_my_age and the
 * call of the function in get_my_age so that the expected value is returned.
 *
 * HINT: C is pass by value
 */

/** HIS SOLUTION:
struct Person {
    char * name;
    int age;
};

Person set_my_age(struct Person * p) {
    (*p).age = 44;              //dereference operator
    OR
    p->age = 44;                // Easy substitution for dereference operator: BINDING
}

int get_my_age() {
    struct Person me;
    me.name = "Carson";
    me = set_my_age(&me);     // Pass field in a pointer        (&(me->foo)->bar)
    return me.age;
}
*/
struct Person {
    char * name;
    int age;
};

Person set_my_age(struct Person p) {
    p.age = 44;
    return p;
}

int get_my_age() {
    struct Person me;
    me.name = "Carson";
    me = set_my_age(me);
    return me.age;
}

TEST(set_my_age, works) {
    EXPECT_EQ(44, get_my_age());
}




